﻿
namespace NUSxam_v1
{
    partial class Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Homepage));
            this.btnHmpgMyExPaper = new System.Windows.Forms.Button();
            this.btnHmpgCreateEx = new System.Windows.Forms.Button();
            this.btnHmpgGradebook = new System.Windows.Forms.Button();
            this.ToolbarPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblHmpgTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ButtonsPanel = new System.Windows.Forms.Panel();
            this.btnHmpgStartEx = new System.Windows.Forms.Button();
            this.startExUC1 = new NUSxam_v1.StartExUC();
            this.myExamPaperUC1 = new NUSxam_v1.MyExamPaperUC();
            this.gradebookUC1 = new NUSxam_v1.GradebookUC();
            this.createExamUC1 = new NUSxam_v1.CreateExamUC();
            this.ToolbarPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ButtonsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnHmpgMyExPaper
            // 
            this.btnHmpgMyExPaper.AutoSize = true;
            this.btnHmpgMyExPaper.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnHmpgMyExPaper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHmpgMyExPaper.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmpgMyExPaper.Image = ((System.Drawing.Image)(resources.GetObject("btnHmpgMyExPaper.Image")));
            this.btnHmpgMyExPaper.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHmpgMyExPaper.Location = new System.Drawing.Point(1, 263);
            this.btnHmpgMyExPaper.Name = "btnHmpgMyExPaper";
            this.btnHmpgMyExPaper.Size = new System.Drawing.Size(334, 122);
            this.btnHmpgMyExPaper.TabIndex = 2;
            this.btnHmpgMyExPaper.Text = "My Exam Paper";
            this.btnHmpgMyExPaper.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHmpgMyExPaper.UseVisualStyleBackColor = false;
            this.btnHmpgMyExPaper.Click += new System.EventHandler(this.btnHmpgMyExPaper_Click);
            // 
            // btnHmpgCreateEx
            // 
            this.btnHmpgCreateEx.AutoSize = true;
            this.btnHmpgCreateEx.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnHmpgCreateEx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHmpgCreateEx.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmpgCreateEx.Image = ((System.Drawing.Image)(resources.GetObject("btnHmpgCreateEx.Image")));
            this.btnHmpgCreateEx.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHmpgCreateEx.Location = new System.Drawing.Point(1, 640);
            this.btnHmpgCreateEx.Name = "btnHmpgCreateEx";
            this.btnHmpgCreateEx.Size = new System.Drawing.Size(334, 122);
            this.btnHmpgCreateEx.TabIndex = 4;
            this.btnHmpgCreateEx.Text = "Create Exam";
            this.btnHmpgCreateEx.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHmpgCreateEx.UseVisualStyleBackColor = false;
            this.btnHmpgCreateEx.Click += new System.EventHandler(this.btnHmpgCreateEx_Click);
            // 
            // btnHmpgGradebook
            // 
            this.btnHmpgGradebook.AutoSize = true;
            this.btnHmpgGradebook.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnHmpgGradebook.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHmpgGradebook.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmpgGradebook.Image = ((System.Drawing.Image)(resources.GetObject("btnHmpgGradebook.Image")));
            this.btnHmpgGradebook.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHmpgGradebook.Location = new System.Drawing.Point(-1, 452);
            this.btnHmpgGradebook.Name = "btnHmpgGradebook";
            this.btnHmpgGradebook.Size = new System.Drawing.Size(334, 122);
            this.btnHmpgGradebook.TabIndex = 3;
            this.btnHmpgGradebook.Text = "Gradebook";
            this.btnHmpgGradebook.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHmpgGradebook.UseVisualStyleBackColor = false;
            this.btnHmpgGradebook.Click += new System.EventHandler(this.btnHmpgGradebook_Click);
            // 
            // ToolbarPanel
            // 
            this.ToolbarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(123)))), ((int)(((byte)(0)))));
            this.ToolbarPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ToolbarPanel.Controls.Add(this.panel1);
            this.ToolbarPanel.Controls.Add(this.pictureBox1);
            this.ToolbarPanel.Controls.Add(this.lblHmpgTime);
            this.ToolbarPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ToolbarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.ToolbarPanel.Location = new System.Drawing.Point(0, 0);
            this.ToolbarPanel.Name = "ToolbarPanel";
            this.ToolbarPanel.Size = new System.Drawing.Size(1924, 138);
            this.ToolbarPanel.TabIndex = 0;

            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(336, 135);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, -26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblHmpgTime
            // 
            this.lblHmpgTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHmpgTime.AutoSize = true;
            this.lblHmpgTime.Location = new System.Drawing.Point(1756, 0);
            this.lblHmpgTime.Name = "lblHmpgTime";
            this.lblHmpgTime.Size = new System.Drawing.Size(46, 17);
            this.lblHmpgTime.TabIndex = 0;
            this.lblHmpgTime.Text = "label1";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ButtonsPanel
            // 
            this.ButtonsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.ButtonsPanel.Controls.Add(this.btnHmpgStartEx);
            this.ButtonsPanel.Controls.Add(this.btnHmpgGradebook);
            this.ButtonsPanel.Controls.Add(this.btnHmpgCreateEx);
            this.ButtonsPanel.Controls.Add(this.btnHmpgMyExPaper);
            this.ButtonsPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ButtonsPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.ButtonsPanel.Location = new System.Drawing.Point(0, 138);
            this.ButtonsPanel.Name = "ButtonsPanel";
            this.ButtonsPanel.Size = new System.Drawing.Size(337, 818);
            this.ButtonsPanel.TabIndex = 1;

            // 
            // btnHmpgStartEx
            // 
            this.btnHmpgStartEx.AutoSize = true;
            this.btnHmpgStartEx.BackColor = System.Drawing.Color.DarkGray;
            this.btnHmpgStartEx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHmpgStartEx.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmpgStartEx.Image = ((System.Drawing.Image)(resources.GetObject("btnHmpgStartEx.Image")));
            this.btnHmpgStartEx.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHmpgStartEx.Location = new System.Drawing.Point(-1, 75);
            this.btnHmpgStartEx.Name = "btnHmpgStartEx";
            this.btnHmpgStartEx.Size = new System.Drawing.Size(334, 122);
            this.btnHmpgStartEx.TabIndex = 1;
            this.btnHmpgStartEx.Text = "Start Exam";
            this.btnHmpgStartEx.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHmpgStartEx.UseVisualStyleBackColor = false;
            this.btnHmpgStartEx.Click += new System.EventHandler(this.btnHmpgStartEx_Click);
            // 
            // startExUC1
            // 
            this.startExUC1.Location = new System.Drawing.Point(337, 138);
            this.startExUC1.Name = "startExUC1";
            this.startExUC1.Size = new System.Drawing.Size(1750, 893);
            this.startExUC1.TabIndex = 2;
            // 
            // myExamPaperUC1
            // 
            this.myExamPaperUC1.Location = new System.Drawing.Point(337, 138);
            this.myExamPaperUC1.Name = "myExamPaperUC1";
            this.myExamPaperUC1.Size = new System.Drawing.Size(1750, 893);
            this.myExamPaperUC1.TabIndex = 3;
            // 
            // gradebookUC1
            // 
            this.gradebookUC1.Location = new System.Drawing.Point(337, 138);
            this.gradebookUC1.Name = "gradebookUC1";
            this.gradebookUC1.Size = new System.Drawing.Size(1750, 893);
            this.gradebookUC1.TabIndex = 4;
            // 
            // createExamUC1
            // 
            this.createExamUC1.Location = new System.Drawing.Point(337, 138);
            this.createExamUC1.Name = "createExamUC1";
            this.createExamUC1.Size = new System.Drawing.Size(1750, 893);
            this.createExamUC1.TabIndex = 5;
            // 
            // Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.ClientSize = new System.Drawing.Size(1924, 956);
            this.Controls.Add(this.createExamUC1);
            this.Controls.Add(this.gradebookUC1);
            this.Controls.Add(this.myExamPaperUC1);
            this.Controls.Add(this.startExUC1);
            this.Controls.Add(this.ButtonsPanel);
            this.Controls.Add(this.ToolbarPanel);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Homepage";
            this.Text = "Homepage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Homepage_FormClosing);
            this.ToolbarPanel.ResumeLayout(false);
            this.ToolbarPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ButtonsPanel.ResumeLayout(false);
            this.ButtonsPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ToolbarPanel;
        private System.Windows.Forms.Label lblHmpgTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel ButtonsPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnHmpgMyExPaper;
        private System.Windows.Forms.Button btnHmpgCreateEx;
        private System.Windows.Forms.Button btnHmpgGradebook;
        private System.Windows.Forms.Button btnHmpgStartEx;
        private StartExUC startExUC1;
        private MyExamPaperUC myExamPaperUC1;
        private GradebookUC gradebookUC1;
        private CreateExamUC createExamUC1;
    }
}