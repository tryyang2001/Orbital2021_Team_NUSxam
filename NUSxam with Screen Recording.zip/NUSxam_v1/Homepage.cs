﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NUSxam_v1
{
    public partial class Homepage : Form
    {
        public Homepage()
        {
            InitializeComponent();
            timer1.Start();
            //initially, start exam UC will show first (default)
            startExUC1.Visible = true;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;
        }

        //show time at the top right corner
        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            this.lblHmpgTime.Text = dateTime.ToString();
        }

        private void btnStartExStart_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The exam starts now :D");
        }

        private void Homepage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure to exit?", "NUSxam", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                for (int i = 0; i < Application.OpenForms.Count; i++)
                {
                    try
                    {
                        Application.OpenForms[i].Close(); //this will close all forms opened
                    }
                    catch { }
                }
            }
            else e.Cancel = true; //cancel the event to prevent closing
        }

        private void btnHmpgStartEx_Click(object sender, EventArgs e)
        {
            //change visibility
            startExUC1.Visible = true;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;
   
            //change button colour display
            btnHmpgStartEx.BackColor = Color.DarkGray;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;
        }

        private void btnHmpgMyExPaper_Click(object sender, EventArgs e)
        {
            //change visibility
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = true;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;

            //change button colour display
            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.DarkGray;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;
        }

        private void btnHmpgGradebook_Click(object sender, EventArgs e)
        {
            //change visibility
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = true;
            createExamUC1.Visible = false;

            //change button colour display
            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.DarkGray;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;
        }

        private void btnHmpgCreateEx_Click(object sender, EventArgs e)
        {
            //change visibility
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = true;

            //change button colour display
            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.DarkGray;
        }
    }
}
