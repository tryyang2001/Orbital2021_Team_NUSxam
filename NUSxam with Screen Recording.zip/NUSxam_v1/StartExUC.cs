﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Accord.Video.FFMPEG;

namespace NUSxam_v1
{
    public partial class StartExUC : UserControl
    {
        //set up for recording 
        VideoFileWriter vfw;
        Bitmap img;
        Graphics g;
        //most of the time the computer recommended screen resolution is 125%
        int screenWidth = Convert.ToInt32(System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Width * 1.25);
        int screenHeight = Convert.ToInt32(System.Windows.Forms.SystemInformation.PrimaryMonitorSize.Height * 1.25);
        string path = ""; //original path is null
        bool isStartRecorded = false;
        RecordingSetup recSetup = new RecordingSetup();
        int curr_time = 0;

        public StartExUC()
        {
            InitializeComponent();
            cmbStartExPaperList.Items.Add("CS1010 Final");
            cmbStartExPaperList.Items.Add("CS1010E Final");
            cmbStartExPaperList.Items.Add("ME2102 Mock Final");
            cmbStartExPaperList.Items.Add("CG1112 Quiz 2");
            lblTimeDisplay.Text = "";
            timer2.Interval = 1000;
            timer2.Enabled = true;
        }

        //timer will start when the UC loads
        private void StartExUC_Load(object sender, EventArgs e)
        {
            timer1 = new Timer();
            timer1.Interval = 500;
            timer1.Tick += timer1_Tick;
        }

        //screen recording button is clicked
        private void btnScreenRec_Click(object sender, EventArgs e)
        {
            if (isStartRecorded == false)
            {
                if (recSetup.IsDisposed)
                {
                    recSetup = new RecordingSetup();
                }

                //once the user has selected the path and click the 'start' button
                if (recSetup.ShowDialog() == DialogResult.OK)
                {
                    path = recSetup.vidpath;
                    MessageBox.Show("Start recording now.");
                    //start recording
                    vfw = new VideoFileWriter();
                    vfw.Open(path, screenWidth, screenHeight, 2, VideoCodec.MPEG4, 10000);
                    timer1.Start(); //timer starts here
                    isStartRecorded = true;
                }
            }

            //when the recording is ongoing
            else
            {
                if (MessageBox.Show("Are you sure to stop recording?", "Stop Recording", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    timer1.Stop();
                    vfw.Close();
                    isStartRecorded = false;
                    curr_time = 0;
                    lblTimeDisplay.Text = "";
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            img = new Bitmap(screenWidth, screenHeight);
            g = Graphics.FromImage(img);
            g.CopyFromScreen(0, 0, 0, 0, img.Size);
            vfw.WriteVideoFrame(img);
            //dispose all these to save memory
            g.Dispose();
            img.Dispose();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (isStartRecorded)
            {
                //less than one minute
                if (curr_time < 60)
                {
                    if (curr_time < 10)
                    {
                        lblTimeDisplay.Text = "0:00:0" + Convert.ToString(curr_time++);
                    }
                    else lblTimeDisplay.Text = "0:00:" + Convert.ToString(curr_time++);
                }
                //less than one hour
                else if (curr_time < 3600)
                {
                    //less than ten minutes
                    if (curr_time / 60 < 10 && curr_time % 60 < 10)
                    {
                        lblTimeDisplay.Text = "0:0" + Convert.ToString(curr_time / 60) + ":0" + Convert.ToString(curr_time % 60);
                    }
                    else
                    {
                        lblTimeDisplay.Text = "0:0" + Convert.ToString(curr_time / 60) + ":" + Convert.ToString(curr_time % 60);
                    }
                }
                else
                {
                    //sec less than 10 but min more than ten
                    if (curr_time % 60 < 10)
                    {
                        lblTimeDisplay.Text = "0:" + Convert.ToString(curr_time / 60) + ":0" + Convert.ToString(curr_time % 60);
                    }
                    else
                    {
                        lblTimeDisplay.Text = "0:" + Convert.ToString(curr_time / 60) + ":" + Convert.ToString(curr_time % 60);
                    }
                }
            }
            //more than 1 hour
            else
            {
                //sec less than 10 and min less than 10
                if (curr_time % 3600 % 60 < 10 && curr_time % 3600 < 10)
                {
                    lblTimeDisplay.Text = Convert.ToString(curr_time / 3600) + ":0" + Convert.ToString(curr_time % 3600 / 60) + ":0" + Convert.ToString(curr_time % 3600 % 60);
                }
                //sec less than 10 but min more than 10
                else if (curr_time % 3600 % 60 < 10 && curr_time % 3600 > 10)
                {
                    lblTimeDisplay.Text = Convert.ToString(curr_time / 3600) + ":" + Convert.ToString(curr_time % 3600 / 60) + ":0" + Convert.ToString(curr_time % 3600 % 60);
                }
                //sec more than 10 but min less than 10
                else if (curr_time % 3600 < 10)
                {
                    lblTimeDisplay.Text = Convert.ToString(curr_time / 3600) + ":0" + Convert.ToString(curr_time % 3600 / 60) + ":" + Convert.ToString(curr_time % 3600 % 60);
                }
                //sec more than 10 and min more than 10
                else
                {
                    lblTimeDisplay.Text = Convert.ToString(curr_time / 3600) + ":" + Convert.ToString(curr_time % 3600 / 60) + ":" + Convert.ToString(curr_time % 3600 % 60);
                    curr_time++;
                }
            }
        }
    }
}
