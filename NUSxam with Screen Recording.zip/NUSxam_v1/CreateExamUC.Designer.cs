﻿
namespace NUSxam_v1
{
    partial class CreateExamUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.StartExTopPanel = new System.Windows.Forms.Panel();
            this.StartExPanel = new System.Windows.Forms.Panel();
            this.btnCreateExam = new System.Windows.Forms.Button();
            this.btnEditEx = new System.Windows.Forms.Button();
            this.StartExTopPanel.SuspendLayout();
            this.StartExPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 68);
            this.label1.TabIndex = 0;
            this.label1.Text = "Create Exam";
            // 
            // StartExTopPanel
            // 
            this.StartExTopPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(123)))), ((int)(((byte)(0)))));
            this.StartExTopPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StartExTopPanel.Controls.Add(this.label1);
            this.StartExTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.StartExTopPanel.Location = new System.Drawing.Point(6, 6);
            this.StartExTopPanel.Name = "StartExTopPanel";
            this.StartExTopPanel.Size = new System.Drawing.Size(1738, 119);
            this.StartExTopPanel.TabIndex = 0;
            // 
            // StartExPanel
            // 
            this.StartExPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.StartExPanel.Controls.Add(this.btnEditEx);
            this.StartExPanel.Controls.Add(this.btnCreateExam);
            this.StartExPanel.Controls.Add(this.StartExTopPanel);
            this.StartExPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.StartExPanel.Location = new System.Drawing.Point(8, 8);
            this.StartExPanel.Name = "StartExPanel";
            this.StartExPanel.Padding = new System.Windows.Forms.Padding(6);
            this.StartExPanel.Size = new System.Drawing.Size(1750, 893);
            this.StartExPanel.TabIndex = 5;
            // 
            // btnCreateExam
            // 
            this.btnCreateExam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCreateExam.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreateExam.Location = new System.Drawing.Point(390, 263);
            this.btnCreateExam.Name = "btnCreateExam";
            this.btnCreateExam.Size = new System.Drawing.Size(909, 164);
            this.btnCreateExam.TabIndex = 1;
            this.btnCreateExam.Text = "Create New Exam";
            this.btnCreateExam.UseVisualStyleBackColor = true;
            // 
            // btnEditEx
            // 
            this.btnEditEx.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEditEx.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEx.Location = new System.Drawing.Point(390, 569);
            this.btnEditEx.Name = "btnEditEx";
            this.btnEditEx.Size = new System.Drawing.Size(909, 164);
            this.btnEditEx.TabIndex = 2;
            this.btnEditEx.Text = "Edit Existing Exam";
            this.btnEditEx.UseVisualStyleBackColor = true;
            // 
            // CreateExamUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.StartExPanel);
            this.Name = "CreateExamUC";
            this.Size = new System.Drawing.Size(1750, 893);
            this.StartExTopPanel.ResumeLayout(false);
            this.StartExTopPanel.PerformLayout();
            this.StartExPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel StartExTopPanel;
        private System.Windows.Forms.Panel StartExPanel;
        private System.Windows.Forms.Button btnEditEx;
        private System.Windows.Forms.Button btnCreateExam;
    }
}
