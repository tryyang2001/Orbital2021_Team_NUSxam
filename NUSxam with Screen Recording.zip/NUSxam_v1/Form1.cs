﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NUSxam_v1
{
    public partial class Form1 : Form
    {
        //create registration form and homepage form
        Registration reg = new Registration();
        Homepage hmpg = new Homepage();

        //set up connection for database
        string path = @"Server = tcp:nusxam.database.windows.net,1433;Initial Catalog = RegistrationDB; Persist Security Info=False;User ID = publicuserlogin; Password=NUSxamOrbital2021; 
                        MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout = 30;";
        SqlConnection conn;

        public Form1()
        {
            conn = new SqlConnection(path);
            InitializeComponent();
        }
    
        //if 'sign up' button is clicked
        private void button1_Click(object sender, EventArgs e)
        {
            if (reg == null || reg.IsDisposed)
            {
                reg = new Registration();
            }
            reg.Show();
        }

        //if 'Show Password' is ticked
        private void chkForm1Pw_CheckedChanged(object sender, EventArgs e)
        {
            txtForm1Pw.PasswordChar = (chkForm1Pw.Checked) ? '\0' : '●';
        }

        private void btnForm1Login_Click(object sender, EventArgs e)
        {
            if (txtForm1Usrname.Text != "" && txtForm1Pw.Text != "")
            {
                //open the database and send the command to check identity
                conn.Open();
                string cmd = "Select User_Username, User_UserPW From RegistrationTb Where User_Username = '" + txtForm1Usrname.Text + "' and User_UserPW ='" + txtForm1Pw.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(cmd, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                conn.Close();

                //if account is registered
                if (dt.Rows.Count == 1)
                {
                    if (hmpg == null || hmpg.IsDisposed)
                    {
                        hmpg = new Homepage();
                    }
                    this.Hide();
                    hmpg.Show();
                }
                else
                {
                    MessageBox.Show("Please check your username and password again.");
                }
            }
            //wrong account identity
            else
            {
                if (txtForm1Pw.Text == "" && txtForm1Usrname.Text == "")
                    MessageBox.Show("Please enter your username and password.");
                else if (txtForm1Usrname.Text == "")
                    MessageBox.Show("Please enter your username.");
                else if (txtForm1Pw.Text == "")
                    MessageBox.Show("Please enter your password.");
            }
        }
    }
}
