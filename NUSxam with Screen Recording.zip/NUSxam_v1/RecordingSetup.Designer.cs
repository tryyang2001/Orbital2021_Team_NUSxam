﻿
namespace NUSxam_v1
{
    partial class RecordingSetup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RecordingSetup));
            this.VidfilePath = new System.Windows.Forms.Label();
            this.btnChoosePath = new System.Windows.Forms.Button();
            this.txtVidfilePath = new System.Windows.Forms.TextBox();
            this.VidfileName = new System.Windows.Forms.Label();
            this.txtVidfileName = new System.Windows.Forms.TextBox();
            this.btnStartRec = new System.Windows.Forms.Button();
            this.btnCancelRec = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // VidfilePath
            // 
            this.VidfilePath.AutoSize = true;
            this.VidfilePath.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VidfilePath.Location = new System.Drawing.Point(25, 103);
            this.VidfilePath.Name = "VidfilePath";
            this.VidfilePath.Size = new System.Drawing.Size(92, 22);
            this.VidfilePath.TabIndex = 0;
            this.VidfilePath.Text = "File Path: ";
            // 
            // btnChoosePath
            // 
            this.btnChoosePath.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChoosePath.Location = new System.Drawing.Point(612, 93);
            this.btnChoosePath.Name = "btnChoosePath";
            this.btnChoosePath.Size = new System.Drawing.Size(126, 42);
            this.btnChoosePath.TabIndex = 1;
            this.btnChoosePath.Text = "Choose folder";
            this.btnChoosePath.UseVisualStyleBackColor = true;
            this.btnChoosePath.Click += new System.EventHandler(this.btnChoosePath_Click);
            // 
            // txtVidfilePath
            // 
            this.txtVidfilePath.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVidfilePath.Location = new System.Drawing.Point(150, 101);
            this.txtVidfilePath.Name = "txtVidfilePath";
            this.txtVidfilePath.ReadOnly = true;
            this.txtVidfilePath.Size = new System.Drawing.Size(440, 28);
            this.txtVidfilePath.TabIndex = 2;
            // 
            // VidfileName
            // 
            this.VidfileName.AutoSize = true;
            this.VidfileName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VidfileName.Location = new System.Drawing.Point(13, 193);
            this.VidfileName.Name = "VidfileName";
            this.VidfileName.Size = new System.Drawing.Size(104, 22);
            this.VidfileName.TabIndex = 3;
            this.VidfileName.Text = "File Name: ";
            // 
            // txtVidfileName
            // 
            this.txtVidfileName.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVidfileName.Location = new System.Drawing.Point(150, 190);
            this.txtVidfileName.Name = "txtVidfileName";
            this.txtVidfileName.Size = new System.Drawing.Size(440, 28);
            this.txtVidfileName.TabIndex = 4;
            // 
            // btnStartRec
            // 
            this.btnStartRec.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartRec.Location = new System.Drawing.Point(464, 305);
            this.btnStartRec.Name = "btnStartRec";
            this.btnStartRec.Size = new System.Drawing.Size(126, 42);
            this.btnStartRec.TabIndex = 5;
            this.btnStartRec.Text = "Start";
            this.btnStartRec.UseVisualStyleBackColor = true;
            this.btnStartRec.Click += new System.EventHandler(this.btnStartRec_Click);
            // 
            // btnCancelRec
            // 
            this.btnCancelRec.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelRec.Location = new System.Drawing.Point(612, 305);
            this.btnCancelRec.Name = "btnCancelRec";
            this.btnCancelRec.Size = new System.Drawing.Size(126, 42);
            this.btnCancelRec.TabIndex = 6;
            this.btnCancelRec.Text = "Cancel";
            this.btnCancelRec.UseVisualStyleBackColor = true;
            this.btnCancelRec.Click += new System.EventHandler(this.btnCancelRec_Click);
            // 
            // RecordingSetup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 399);
            this.Controls.Add(this.btnCancelRec);
            this.Controls.Add(this.btnStartRec);
            this.Controls.Add(this.txtVidfileName);
            this.Controls.Add(this.VidfileName);
            this.Controls.Add(this.txtVidfilePath);
            this.Controls.Add(this.btnChoosePath);
            this.Controls.Add(this.VidfilePath);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RecordingSetup";
            this.Text = "RecordingSetup";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label VidfilePath;
        private System.Windows.Forms.Button btnChoosePath;
        private System.Windows.Forms.TextBox txtVidfilePath;
        private System.Windows.Forms.Label VidfileName;
        private System.Windows.Forms.TextBox txtVidfileName;
        private System.Windows.Forms.Button btnStartRec;
        private System.Windows.Forms.Button btnCancelRec;
    }
}