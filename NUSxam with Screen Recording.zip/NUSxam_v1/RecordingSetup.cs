﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NUSxam_v1
{
    public partial class RecordingSetup : Form
    {
        //declare video path directory
        public string vidpath = "";
        public bool isReady = false;
        public RecordingSetup()
        {
            InitializeComponent();
        }

        private void btnChoosePath_Click(object sender, EventArgs e)
        {
            //open file browser
            FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog();
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtVidfilePath.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        //when 'start' button is clicked
        private void btnStartRec_Click(object sender, EventArgs e)
        {
            if (txtVidfileName.Text == "")
            {
                MessageBox.Show("Please enter the file name.");
            }
            else if (txtVidfilePath.Text == "")
            {
                MessageBox.Show("The video path is missing.");
            }
            else
            {
                //send result StartExUC to start the recording
                vidpath = txtVidfilePath.Text + "//" + txtVidfileName.Text +".mp4";
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnCancelRec_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
