﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NUSxam_v1
{
    public partial class Homepage : Form
    {
        public Homepage()
        {          
            InitializeComponent();
            timer1.Start();
            startExUC1.Visible = true;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            this.lblHmpgTime.Text = dateTime.ToString();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Homepage_Load(object sender, EventArgs e)
        {
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void StartExPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnStartExStart_Click(object sender, EventArgs e)
        {

        }

        private void Homepage_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure to exit?", "NUSxam", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                for (int i = 0; i < Application.OpenForms.Count; i++)
                {
                    try
                    {
                        Application.OpenForms[i].Close();
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void btnHmpgStartEx_Click(object sender, EventArgs e)
        {
            startExUC1.Visible = true;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;
   
            btnHmpgStartEx.BackColor = Color.DarkGray;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;

        }

        private void btnHmpgMyExPaper_Click(object sender, EventArgs e)
        {
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = true;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = false;

            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.DarkGray;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;
 
        }

        private void btnHmpgGradebook_Click(object sender, EventArgs e)
        {
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = true;
            createExamUC1.Visible = false;

            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.DarkGray;
            btnHmpgCreateEx.BackColor = Color.WhiteSmoke;

        }

        private void btnHmpgCreateEx_Click(object sender, EventArgs e)
        {
            startExUC1.Visible = false;
            myExamPaperUC1.Visible = false;
            gradebookUC1.Visible = false;
            createExamUC1.Visible = true;
 
            btnHmpgStartEx.BackColor = Color.WhiteSmoke;
            btnHmpgMyExPaper.BackColor = Color.WhiteSmoke;
            btnHmpgGradebook.BackColor = Color.WhiteSmoke;
            btnHmpgCreateEx.BackColor = Color.DarkGray;

        }


    }
}
