﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NUSxam_v1
{
    public partial class StartExUC : UserControl
    {
        public StartExUC()
        {
            InitializeComponent();
            cmbStartExPaperList.Items.Add("CS1010 Final");
            cmbStartExPaperList.Items.Add("CS1010E Final");
            cmbStartExPaperList.Items.Add("ME2102 Mock Final");
            cmbStartExPaperList.Items.Add("CG1112 Quiz 2");
        }

        private void cmbStartExPaperList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void StartExUC_Load(object sender, EventArgs e)
        {

        }
    }
}
