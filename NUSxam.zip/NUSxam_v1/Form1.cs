﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace NUSxam_v1
{
    public partial class Form1 : Form
    {
        Registration reg = new Registration();
        Homepage hmpg = new Homepage();
        string path = @"Data Source=172.31.97.159, 1433; Initial Catalog=RegistrationDB; Integrated Security=false; User ID=publicuser; Password=NUSxam2021; ";
        SqlConnection conn;
        public Form1()
        {
            conn = new SqlConnection(path);
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            if (reg == null || reg.IsDisposed)
            {
                reg = new Registration();
            }
            reg.Show();

        }

        private void chkForm1Pw_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkForm1Pw.Checked)
            {
                txtForm1Pw.PasswordChar = '●';
            }
            else
            {
                txtForm1Pw.PasswordChar = '\0';
            }
        }

        private void btnForm1Login_Click(object sender, EventArgs e)
        {
            if (txtForm1Usrname.Text != "" && txtForm1Pw.Text != "")
            {
                conn.Open();
                string cmd = "Select User_Username, User_UserPW From RegistrationTb Where User_Username = '" + txtForm1Usrname.Text + "' and User_UserPW ='" + txtForm1Pw.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(cmd, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                conn.Close();
                if (dt.Rows.Count == 1)
                {
                    if (hmpg == null || hmpg.IsDisposed)
                    {
                        hmpg = new Homepage();
                    }
                    this.Hide();
                    hmpg.Show();
                }
                else
                {
                    MessageBox.Show("Please check your username and password again.");
                }
            }
            else
            {
                if (txtForm1Pw.Text == "" && txtForm1Usrname.Text == "")
                    MessageBox.Show("Please enter your username and password.");
                else if (txtForm1Usrname.Text == "")
                    MessageBox.Show("Please enter your username.");
                else if (txtForm1Pw.Text == "")
                    MessageBox.Show("Please enter your password.");
            }
        }
    }
}
