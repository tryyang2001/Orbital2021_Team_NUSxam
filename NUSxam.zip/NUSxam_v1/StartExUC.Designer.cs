﻿
namespace NUSxam_v1
{
    partial class StartExUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartExUC));
            this.StartExPanel = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbStartExPaperList = new System.Windows.Forms.ComboBox();
            this.btnStartExStart = new System.Windows.Forms.Button();
            this.StartExTopPanel = new System.Windows.Forms.Panel();
            this.btnChatBox = new System.Windows.Forms.Button();
            this.btnScreenRec = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.StartExPanel.SuspendLayout();
            this.StartExTopPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // StartExPanel
            // 
            this.StartExPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.StartExPanel.Controls.Add(this.textBox4);
            this.StartExPanel.Controls.Add(this.textBox3);
            this.StartExPanel.Controls.Add(this.textBox2);
            this.StartExPanel.Controls.Add(this.textBox1);
            this.StartExPanel.Controls.Add(this.label5);
            this.StartExPanel.Controls.Add(this.label4);
            this.StartExPanel.Controls.Add(this.label3);
            this.StartExPanel.Controls.Add(this.label2);
            this.StartExPanel.Controls.Add(this.cmbStartExPaperList);
            this.StartExPanel.Controls.Add(this.btnStartExStart);
            this.StartExPanel.Controls.Add(this.StartExTopPanel);
            this.StartExPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.StartExPanel.Location = new System.Drawing.Point(8, 8);
            this.StartExPanel.Name = "StartExPanel";
            this.StartExPanel.Padding = new System.Windows.Forms.Padding(6);
            this.StartExPanel.Size = new System.Drawing.Size(1750, 893);
            this.StartExPanel.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(425, 620);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(903, 43);
            this.textBox4.TabIndex = 10;
            this.textBox4.TabStop = false;
            this.textBox4.Text = "Yes";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Black;
            this.textBox3.Location = new System.Drawing.Point(427, 532);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(903, 43);
            this.textBox3.TabIndex = 9;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "MCQ, MRQ, Short Esaay";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(425, 437);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(903, 43);
            this.textBox2.TabIndex = 8;
            this.textBox2.TabStop = false;
            this.textBox2.Text = "Prof Stiffen Hanlim";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(425, 355);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(903, 43);
            this.textBox1.TabIndex = 7;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "2 hours";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(58, 622);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(320, 43);
            this.label5.TabIndex = 6;
            this.label5.Text = "Recording Needed: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(142, 528);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(236, 43);
            this.label4.TabIndex = 5;
            this.label4.Text = "Exam format: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(152, 437);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(236, 43);
            this.label3.TabIndex = 4;
            this.label3.Text = "Exam Setter:  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(205, 355);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(173, 43);
            this.label2.TabIndex = 3;
            this.label2.Text = "Duration: ";
            // 
            // cmbStartExPaperList
            // 
            this.cmbStartExPaperList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStartExPaperList.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStartExPaperList.FormattingEnabled = true;
            this.cmbStartExPaperList.Location = new System.Drawing.Point(384, 216);
            this.cmbStartExPaperList.Name = "cmbStartExPaperList";
            this.cmbStartExPaperList.Size = new System.Drawing.Size(963, 54);
            this.cmbStartExPaperList.TabIndex = 2;
            this.cmbStartExPaperList.TabStop = false;
            this.cmbStartExPaperList.SelectedIndexChanged += new System.EventHandler(this.cmbStartExPaperList_SelectedIndexChanged);
            // 
            // btnStartExStart
            // 
            this.btnStartExStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnStartExStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStartExStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartExStart.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartExStart.Location = new System.Drawing.Point(935, 734);
            this.btnStartExStart.Name = "btnStartExStart";
            this.btnStartExStart.Size = new System.Drawing.Size(389, 71);
            this.btnStartExStart.TabIndex = 1;
            this.btnStartExStart.TabStop = false;
            this.btnStartExStart.Text = "Start ";
            this.btnStartExStart.UseVisualStyleBackColor = false;
            // 
            // StartExTopPanel
            // 
            this.StartExTopPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(123)))), ((int)(((byte)(0)))));
            this.StartExTopPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StartExTopPanel.Controls.Add(this.btnChatBox);
            this.StartExTopPanel.Controls.Add(this.btnScreenRec);
            this.StartExTopPanel.Controls.Add(this.label1);
            this.StartExTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.StartExTopPanel.Location = new System.Drawing.Point(6, 6);
            this.StartExTopPanel.Name = "StartExTopPanel";
            this.StartExTopPanel.Size = new System.Drawing.Size(1738, 119);
            this.StartExTopPanel.TabIndex = 0;
            // 
            // btnChatBox
            // 
            this.btnChatBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChatBox.FlatAppearance.BorderSize = 0;
            this.btnChatBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChatBox.Image = ((System.Drawing.Image)(resources.GetObject("btnChatBox.Image")));
            this.btnChatBox.Location = new System.Drawing.Point(1425, 0);
            this.btnChatBox.Name = "btnChatBox";
            this.btnChatBox.Size = new System.Drawing.Size(187, 122);
            this.btnChatBox.TabIndex = 2;
            this.btnChatBox.TabStop = false;
            this.btnChatBox.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnChatBox.UseVisualStyleBackColor = true;
            // 
            // btnScreenRec
            // 
            this.btnScreenRec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScreenRec.FlatAppearance.BorderSize = 0;
            this.btnScreenRec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScreenRec.Image = ((System.Drawing.Image)(resources.GetObject("btnScreenRec.Image")));
            this.btnScreenRec.Location = new System.Drawing.Point(1251, 3);
            this.btnScreenRec.Name = "btnScreenRec";
            this.btnScreenRec.Size = new System.Drawing.Size(187, 122);
            this.btnScreenRec.TabIndex = 1;
            this.btnScreenRec.TabStop = false;
            this.btnScreenRec.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnScreenRec.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 68);
            this.label1.TabIndex = 0;
            this.label1.Text = "Start Exam";
            // 
            // StartExUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.StartExPanel);
            this.Name = "StartExUC";
            this.Size = new System.Drawing.Size(1750, 893);
            this.Load += new System.EventHandler(this.StartExUC_Load);
            this.StartExPanel.ResumeLayout(false);
            this.StartExPanel.PerformLayout();
            this.StartExTopPanel.ResumeLayout(false);
            this.StartExTopPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel StartExPanel;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbStartExPaperList;
        private System.Windows.Forms.Button btnStartExStart;
        private System.Windows.Forms.Panel StartExTopPanel;
        private System.Windows.Forms.Button btnChatBox;
        private System.Windows.Forms.Button btnScreenRec;
        private System.Windows.Forms.Label label1;
    }
}
