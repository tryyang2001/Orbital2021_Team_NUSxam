﻿
namespace NUSxam_v1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtForm1Usrname = new System.Windows.Forms.TextBox();
            this.btnForm1Login = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtForm1Pw = new System.Windows.Forms.TextBox();
            this.chkForm1Pw = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(235, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(385, 223);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(198, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "Username: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(198, 338);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 22);
            this.label3.TabIndex = 4;
            this.label3.Text = "Password: ";
            // 
            // txtForm1Usrname
            // 
            this.txtForm1Usrname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForm1Usrname.Location = new System.Drawing.Point(314, 277);
            this.txtForm1Usrname.Multiline = true;
            this.txtForm1Usrname.Name = "txtForm1Usrname";
            this.txtForm1Usrname.Size = new System.Drawing.Size(306, 28);
            this.txtForm1Usrname.TabIndex = 1;
            this.txtForm1Usrname.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btnForm1Login
            // 
            this.btnForm1Login.BackColor = System.Drawing.Color.Lime;
            this.btnForm1Login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnForm1Login.FlatAppearance.BorderSize = 0;
            this.btnForm1Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnForm1Login.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnForm1Login.Location = new System.Drawing.Point(314, 396);
            this.btnForm1Login.Name = "btnForm1Login";
            this.btnForm1Login.Size = new System.Drawing.Size(176, 43);
            this.btnForm1Login.TabIndex = 4;
            this.btnForm1Login.Text = "Login";
            this.btnForm1Login.UseVisualStyleBackColor = false;
            this.btnForm1Login.Click += new System.EventHandler(this.btnForm1Login_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DodgerBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(69)))), ((int)(((byte)(173)))));
            this.button1.Location = new System.Drawing.Point(562, 406);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 31);
            this.button1.TabIndex = 5;
            this.button1.Text = "Sign Up";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.DodgerBlue;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.White;
            this.textBox3.Location = new System.Drawing.Point(510, 414);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(75, 18);
            this.textBox3.TabIndex = 100;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "New user?";
            // 
            // txtForm1Pw
            // 
            this.txtForm1Pw.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtForm1Pw.Location = new System.Drawing.Point(314, 333);
            this.txtForm1Pw.Multiline = true;
            this.txtForm1Pw.Name = "txtForm1Pw";
            this.txtForm1Pw.PasswordChar = '●';
            this.txtForm1Pw.Size = new System.Drawing.Size(306, 28);
            this.txtForm1Pw.TabIndex = 2;
            // 
            // chkForm1Pw
            // 
            this.chkForm1Pw.AutoSize = true;
            this.chkForm1Pw.Location = new System.Drawing.Point(630, 338);
            this.chkForm1Pw.Name = "chkForm1Pw";
            this.chkForm1Pw.Size = new System.Drawing.Size(129, 21);
            this.chkForm1Pw.TabIndex = 3;
            this.chkForm1Pw.Text = "Show Password";
            this.chkForm1Pw.UseVisualStyleBackColor = true;
            this.chkForm1Pw.CheckedChanged += new System.EventHandler(this.chkForm1Pw_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(878, 515);
            this.Controls.Add(this.chkForm1Pw);
            this.Controls.Add(this.txtForm1Pw);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnForm1Login);
            this.Controls.Add(this.txtForm1Usrname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtForm1Usrname;
        private System.Windows.Forms.Button btnForm1Login;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtForm1Pw;
        private System.Windows.Forms.CheckBox chkForm1Pw;
    }
}

