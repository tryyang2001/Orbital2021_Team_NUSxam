﻿
namespace NUSxam_v1
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.label1 = new System.Windows.Forms.Label();
            this.txtRegFirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtRegPw = new System.Windows.Forms.TextBox();
            this.txtRegCPw = new System.Windows.Forms.TextBox();
            this.txtRegEmail = new System.Windows.Forms.TextBox();
            this.txtRegUsrname = new System.Windows.Forms.TextBox();
            this.txtRegLastName = new System.Windows.Forms.TextBox();
            this.btnRegConfirm = new System.Windows.Forms.Button();
            this.btnRegClear = new System.Windows.Forms.Button();
            this.cmbRegSchool = new System.Windows.Forms.ComboBox();
            this.chkRegPw = new System.Windows.Forms.CheckBox();
            this.chkRegCPw = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(171, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username: ";
            // 
            // txtRegFirstName
            // 
            this.txtRegFirstName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegFirstName.Location = new System.Drawing.Point(289, 74);
            this.txtRegFirstName.Name = "txtRegFirstName";
            this.txtRegFirstName.Size = new System.Drawing.Size(368, 28);
            this.txtRegFirstName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(156, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "First Name: ";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(158, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 21);
            this.label3.TabIndex = 3;
            this.label3.Text = "Last Name: ";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(104, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 21);
            this.label4.TabIndex = 4;
            this.label4.Text = "Confirm Password: ";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(164, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 21);
            this.label5.TabIndex = 5;
            this.label5.Text = "Password: ";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(113, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 21);
            this.label6.TabIndex = 6;
            this.label6.Text = "School/Institution: ";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(197, 370);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 21);
            this.label7.TabIndex = 7;
            this.label7.Text = "Email: ";
            // 
            // txtRegPw
            // 
            this.txtRegPw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegPw.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegPw.Location = new System.Drawing.Point(289, 221);
            this.txtRegPw.Name = "txtRegPw";
            this.txtRegPw.PasswordChar = '●';
            this.txtRegPw.Size = new System.Drawing.Size(370, 28);
            this.txtRegPw.TabIndex = 4;
            // 
            // txtRegCPw
            // 
            this.txtRegCPw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegCPw.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegCPw.Location = new System.Drawing.Point(289, 273);
            this.txtRegCPw.Name = "txtRegCPw";
            this.txtRegCPw.PasswordChar = '●';
            this.txtRegCPw.Size = new System.Drawing.Size(370, 28);
            this.txtRegCPw.TabIndex = 6;
            // 
            // txtRegEmail
            // 
            this.txtRegEmail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegEmail.Location = new System.Drawing.Point(289, 365);
            this.txtRegEmail.Name = "txtRegEmail";
            this.txtRegEmail.Size = new System.Drawing.Size(370, 28);
            this.txtRegEmail.TabIndex = 9;
            // 
            // txtRegUsrname
            // 
            this.txtRegUsrname.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegUsrname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegUsrname.Location = new System.Drawing.Point(289, 172);
            this.txtRegUsrname.Name = "txtRegUsrname";
            this.txtRegUsrname.Size = new System.Drawing.Size(370, 28);
            this.txtRegUsrname.TabIndex = 3;
            // 
            // txtRegLastName
            // 
            this.txtRegLastName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRegLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegLastName.Location = new System.Drawing.Point(289, 128);
            this.txtRegLastName.Name = "txtRegLastName";
            this.txtRegLastName.Size = new System.Drawing.Size(370, 28);
            this.txtRegLastName.TabIndex = 2;
            // 
            // btnRegConfirm
            // 
            this.btnRegConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRegConfirm.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRegConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegConfirm.FlatAppearance.BorderSize = 0;
            this.btnRegConfirm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRegConfirm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnRegConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegConfirm.Location = new System.Drawing.Point(562, 433);
            this.btnRegConfirm.Name = "btnRegConfirm";
            this.btnRegConfirm.Size = new System.Drawing.Size(97, 33);
            this.btnRegConfirm.TabIndex = 11;
            this.btnRegConfirm.Text = "Confirm";
            this.btnRegConfirm.UseVisualStyleBackColor = false;
            this.btnRegConfirm.Click += new System.EventHandler(this.btnRegConfirm_Click);
            // 
            // btnRegClear
            // 
            this.btnRegClear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRegClear.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRegClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegClear.FlatAppearance.BorderSize = 0;
            this.btnRegClear.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnRegClear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btnRegClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegClear.Location = new System.Drawing.Point(437, 433);
            this.btnRegClear.Name = "btnRegClear";
            this.btnRegClear.Size = new System.Drawing.Size(97, 33);
            this.btnRegClear.TabIndex = 10;
            this.btnRegClear.Text = "Clear";
            this.btnRegClear.UseVisualStyleBackColor = false;
            this.btnRegClear.Click += new System.EventHandler(this.btnRegClear_Click);
            // 
            // cmbRegSchool
            // 
            this.cmbRegSchool.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbRegSchool.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegSchool.FormattingEnabled = true;
            this.cmbRegSchool.Location = new System.Drawing.Point(289, 324);
            this.cmbRegSchool.Name = "cmbRegSchool";
            this.cmbRegSchool.Size = new System.Drawing.Size(368, 24);
            this.cmbRegSchool.TabIndex = 8;
            // 
            // chkRegPw
            // 
            this.chkRegPw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkRegPw.AutoSize = true;
            this.chkRegPw.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRegPw.Location = new System.Drawing.Point(685, 225);
            this.chkRegPw.Name = "chkRegPw";
            this.chkRegPw.Size = new System.Drawing.Size(125, 21);
            this.chkRegPw.TabIndex = 5;
            this.chkRegPw.Text = "Show Password";
            this.chkRegPw.UseVisualStyleBackColor = true;
            this.chkRegPw.CheckedChanged += new System.EventHandler(this.chkRegPw_CheckedChanged);
            // 
            // chkRegCPw
            // 
            this.chkRegCPw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.chkRegCPw.AutoSize = true;
            this.chkRegCPw.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRegCPw.Location = new System.Drawing.Point(685, 277);
            this.chkRegCPw.Name = "chkRegCPw";
            this.chkRegCPw.Size = new System.Drawing.Size(125, 21);
            this.chkRegCPw.TabIndex = 7;
            this.chkRegCPw.Text = "Show Password";
            this.chkRegCPw.UseVisualStyleBackColor = true;
            this.chkRegCPw.CheckedChanged += new System.EventHandler(this.chkRegCPw_CheckedChanged);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.ClientSize = new System.Drawing.Size(872, 542);
            this.Controls.Add(this.chkRegCPw);
            this.Controls.Add(this.chkRegPw);
            this.Controls.Add(this.cmbRegSchool);
            this.Controls.Add(this.btnRegClear);
            this.Controls.Add(this.btnRegConfirm);
            this.Controls.Add(this.txtRegLastName);
            this.Controls.Add(this.txtRegUsrname);
            this.Controls.Add(this.txtRegEmail);
            this.Controls.Add(this.txtRegCPw);
            this.Controls.Add(this.txtRegPw);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtRegFirstName);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRegFirstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtRegPw;
        private System.Windows.Forms.TextBox txtRegCPw;
        private System.Windows.Forms.TextBox txtRegEmail;
        private System.Windows.Forms.TextBox txtRegUsrname;
        private System.Windows.Forms.TextBox txtRegLastName;
        private System.Windows.Forms.Button btnRegConfirm;
        private System.Windows.Forms.Button btnRegClear;
        private System.Windows.Forms.ComboBox cmbRegSchool;
        private System.Windows.Forms.CheckBox chkRegPw;
        private System.Windows.Forms.CheckBox chkRegCPw;
    }
}