﻿
namespace NUSxam_v1
{
    partial class AnnouncementUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartExPanel = new System.Windows.Forms.Panel();
            this.StartExTopPanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.StartExPanel.SuspendLayout();
            this.StartExTopPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // StartExPanel
            // 
            this.StartExPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(63)))), ((int)(((byte)(127)))));
            this.StartExPanel.Controls.Add(this.StartExTopPanel);
            this.StartExPanel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.StartExPanel.Location = new System.Drawing.Point(8, 8);
            this.StartExPanel.Name = "StartExPanel";
            this.StartExPanel.Padding = new System.Windows.Forms.Padding(6);
            this.StartExPanel.Size = new System.Drawing.Size(1750, 893);
            this.StartExPanel.TabIndex = 4;
            // 
            // StartExTopPanel
            // 
            this.StartExTopPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(123)))), ((int)(((byte)(0)))));
            this.StartExTopPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.StartExTopPanel.Controls.Add(this.label1);
            this.StartExTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.StartExTopPanel.Location = new System.Drawing.Point(6, 6);
            this.StartExTopPanel.Name = "StartExTopPanel";
            this.StartExTopPanel.Size = new System.Drawing.Size(1738, 119);
            this.StartExTopPanel.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(415, 68);
            this.label1.TabIndex = 0;
            this.label1.Text = "Announcement";
            // 
            // AnnouncementUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.StartExPanel);
            this.Name = "AnnouncementUC";
            this.Size = new System.Drawing.Size(1750, 893);
            this.StartExPanel.ResumeLayout(false);
            this.StartExTopPanel.ResumeLayout(false);
            this.StartExTopPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel StartExPanel;
        private System.Windows.Forms.Panel StartExTopPanel;
        private System.Windows.Forms.Label label1;
    }
}
