﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace NUSxam_v1
{
    public partial class Registration : Form
    {
        string path = @"Data Source=172.31.97.159, 1433; Initial Catalog=RegistrationDB; Integrated Security=false; User ID=publicuser; Password=NUSxam2021; ";
        SqlConnection conn;
        SqlCommand cmd;
        public Registration()
        {
            InitializeComponent();
            conn = new SqlConnection(path);
            addallschool();
        }

        void addallschool()
        {
            cmbRegSchool.Items.Add("");
            cmbRegSchool.Items.Add("National University of Singapore (NUS)");
            cmbRegSchool.Items.Add("Nanyang Technological University of Singapore (NTU)");
            cmbRegSchool.Items.Add("Singapore Management University (SMU)");
            cmbRegSchool.Items.Add("Singapore University of Technology and Design (SUTD)");
            cmbRegSchool.Items.Add("Singapore Institute of Technology (SIT)");
            cmbRegSchool.Items.Add("Singapore University of Social Sciences (SUSS)");
            cmbRegSchool.Items.Add("Singapore Polytechnic");
            cmbRegSchool.Items.Add("Ngee Ann Polytechnic");
            cmbRegSchool.Items.Add("Temasek Polytechnic");
            cmbRegSchool.Items.Add("Nanyang Polytechnic");
            cmbRegSchool.Items.Add("Republic Polytechnic");
            cmbRegSchool.Items.Add("Anderson Junior College");
            cmbRegSchool.Items.Add("Anglo-Chinese School (Independent) IB World School");
            cmbRegSchool.Items.Add("Anglo-Chinese Junior College");
            cmbRegSchool.Items.Add("Catholic Junior College");
            cmbRegSchool.Items.Add("Dunman High School");
            cmbRegSchool.Items.Add("Hwa Chong Institution");
            cmbRegSchool.Items.Add("Innova Junior College");
            cmbRegSchool.Items.Add("Jurong Junior College");
            cmbRegSchool.Items.Add("Meridian Junior College");
            cmbRegSchool.Items.Add("Millennia Institute");
            cmbRegSchool.Items.Add("Nanyang Junior College");
            cmbRegSchool.Items.Add("National Junior College");
            cmbRegSchool.Items.Add("NUS High School of Mathematics and Science");
            cmbRegSchool.Items.Add("Pioneer Junior College");
            cmbRegSchool.Items.Add("Raffles Junior College");
            cmbRegSchool.Items.Add("River Valley High School");
            cmbRegSchool.Items.Add("Serangoon Junior College");
            cmbRegSchool.Items.Add("Saint Andrew's Junior College");
            cmbRegSchool.Items.Add("Tampines Junior College");
            cmbRegSchool.Items.Add("Temasek Junior College");
            cmbRegSchool.Items.Add("Victoria Junior College");
            cmbRegSchool.Items.Add("Yishun Junior College");
            cmbRegSchool.Items.Add("Hwa Chong Institution");
            cmbRegSchool.Items.Add("Maris Stella High School");
            cmbRegSchool.Items.Add("Nan Hua High School");
            cmbRegSchool.Items.Add("Nanyang Girls' High School");
            cmbRegSchool.Items.Add("River Valley High School");
            cmbRegSchool.Items.Add("Anglican High School");
            cmbRegSchool.Items.Add("Catholic High School");
            cmbRegSchool.Items.Add("CHIJ St. Nicholas Girls' School");
            cmbRegSchool.Items.Add("Chung Cheng High School");
            cmbRegSchool.Items.Add("Dunman High School");
            cmbRegSchool.Items.Add("NUS High School of Mathematics and Science");
            cmbRegSchool.Items.Add("School of the Arts, Singapore");
            cmbRegSchool.Items.Add("School of Science and Technology, Singapore");
            cmbRegSchool.Items.Add("Singapore Sports School");
            cmbRegSchool.Items.Add("Cambridge Institute");
            cmbRegSchool.Items.Add("City College");
        }

        private void btnRegClear_Click(object sender, EventArgs e)
        {
            txtRegFirstName.Text = "";
            txtRegLastName.Text = "";
            txtRegUsrname.Text = "";
            txtRegPw.Text = "";
            txtRegCPw.Text = "";
            cmbRegSchool.Text = "";
            txtRegEmail.Text = "";
        }

        bool isValidEmail(string e)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(e);
                return addr.Address == e;
            }
            catch
            {
                return false;
            }
        }

        private void btnRegConfirm_Click(object sender, EventArgs e)
        {
            if (txtRegFirstName.Text == "" || txtRegLastName.Text == "" || txtRegUsrname.Text == "" || txtRegPw.Text == "" || txtRegCPw.Text == "" || cmbRegSchool.Text == "" || txtRegEmail.Text == "")
            {
                MessageBox.Show("Please fill in all the blanks.");
            }
            else
            {
                if (txtRegCPw.Text != txtRegPw.Text)
                {
                    MessageBox.Show("Password incorrect, please check again.");
                }
                else {
                    if (txtRegFirstName.Text.Any(char.IsDigit) || txtRegLastName.Text.Any(char.IsDigit))
                        MessageBox.Show("Please ensure that the name does not contain digits.");
                    else if (txtRegUsrname.Text.Length < 6)
                        MessageBox.Show("Please enter at least 6 characters for username.");
                    else if (txtRegPw.Text.Length < 8)
                        MessageBox.Show("Please enter at least 8 characters for password.");
                    else if (!isValidEmail(txtRegEmail.Text))
                        MessageBox.Show("Please enter a valid email.");
                    else
                    {
                        conn.Open();
                        string checkSame = "Select User_Username from RegistrationTb Where User_Username='" + txtRegUsrname.Text + "'";
                        SqlDataAdapter sda = new SqlDataAdapter(checkSame, conn);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            MessageBox.Show("The username is already taken, please choose another one.");
                            conn.Close();
                        }
                        
                        else
                        {
                            cmd = new SqlCommand("Insert into RegistrationTb (User_FirstName, User_LastName, User_Username, User_UserPw, User_School, User_Email)" +
                                " Values('" + txtRegFirstName.Text + "', '" + txtRegLastName.Text + "', '" + txtRegUsrname.Text + "', '" + txtRegPw.Text + "', '" + cmbRegSchool.Text + "', '" + txtRegEmail.Text + "')", conn);
                            cmd.ExecuteNonQuery();
                            conn.Close();
                            MessageBox.Show("Your account has been successfully registered.");
                            this.Close();
                        }
                    }
                }
            }
        }

        private void chkRegPw_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRegPw.Checked == true)
            {
                txtRegPw.PasswordChar = '\0'; 
            }
            else
            {
                txtRegPw.PasswordChar = '●';
            }
        }

        private void chkRegCPw_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRegCPw.Checked == true)
            {
                txtRegCPw.PasswordChar = '\0';
            }
            else
            {
                txtRegCPw.PasswordChar = '●';
            }
        }


    }
}
